import React from 'react';
import { render } from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
// Import routing components
import { createStore } from 'redux'
import combineApp from './reducers/reducer';
import {
    addTodo
} from './actions'
import { Provider } from 'react-redux'

const store = createStore(combineApp);

// Log the initial state
console.log(store.getState())

// Every time the state changes, log it
// Note that subscribe() returns a function for unregistering the listener
const unsubscribe = store.subscribe(() =>
    console.log('sub',store.getState())
)

store.dispatch(addTodo('Learn about actions'))
store.dispatch(addTodo('Learn about reducers'))
store.dispatch(addTodo('Learn about store'))


render(
    <Provider store={store}>
    <App/>
    </Provider>,
    document.getElementById('root')
);

// Stop listening to state updates
unsubscribe()
registerServiceWorker();
