import { combineReducers } from 'redux'

const initialState = {
    visibilityFilter: 'SHOW_ALL',
    todos: []
}

function TodoReducer(state = initialState, action) {
    switch (action.type) {
        case 'ADD_TODO':
            return Object.assign({}, state, {
                text: action.text
            })            
    
        default:
            return state
    } 
}

const combineApp = combineReducers({
    TodoReducer    
})

export default combineApp;