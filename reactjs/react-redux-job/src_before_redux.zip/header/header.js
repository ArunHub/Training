import React from 'react';
import { NavLink } from 'react-router-dom';
import './header.css';

class Header extends React.Component {
    render() {
        return (
            <header>
                <ul>
                    <li><NavLink to="/">Home</NavLink></li> 
                    <li><NavLink to="/job-list">Job list</NavLink></li> 
                    <li><NavLink to="/applied-jobs">Applied jobs list</NavLink></li> 
                </ul>
            </header>
        )
    }
}

export default Header;  