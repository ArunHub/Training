import React, { Component } from 'react';

class EE extends Component {

    render() {
        return (
            <div>Modified content</div>
        );
    }
}

export default EE;