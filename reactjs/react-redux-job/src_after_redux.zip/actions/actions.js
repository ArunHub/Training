export const ADD_TODO = 'ADD_TODO';
export const LOAD_CMS = 'LOAD_CMS';
export const DECREMENT_POS = 'DECREMENT_POS';
export const APPLY_JOB = 'APPLY_JOB';

export function addTodo (text){
    return {
        type: ADD_TODO,
        text
    }
}

export function loadCms(cms) {
    // console.log(cms,'cms');
    return {
        type: LOAD_CMS,
        cms
    }
}

export function decrPos(id) {
    return {
        type: DECREMENT_POS,
        id
    }
}

export function applyJob(obj) {
    return {
        type: APPLY_JOB,
        obj
    }
}