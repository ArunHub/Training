import React, { Component } from 'react';
import Header from "./header/header";
import { Route, Switch } from 'react-router-dom';
import JobList from './job-list/job-list';
import jobService from './service';
import Form from "./form/form";
import AppliedJobs from "./applied-jobs";
import { loadCms, addTodo, decrPos, applyJob } from './actions/actions';

class Homepage extends Component {

  joblist;
  store;

  constructor(props) {
    super(props);
    this.store = props.store;

    this.state = {
      job: null
    }
    this.applyJob = this.applyJob.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
    
  componentDidMount() {
    
    jobService.getCMS().then((success) => {
      this.store.dispatch(loadCms(success.content));
      this.store.dispatch(addTodo('Learn about actions'))
    },
      (error) => {
        console.log('errrow while receive response', error)
      });

    const unsubscribe = this.store.subscribe(() =>
      console.log('unsubscribe', this.store.getState())
    )
  }

  applyJob(val) {
    if (val.positions === 0) return false;
    this.store.dispatch(decrPos(val.id));
    this.setState({
      job: val
    })
  }

  handleSubmit(val) {
    this.store.dispatch(applyJob(val));
  }

  render() {
    return (
      <div className="App">
        <Header />
        <Route path="/" exact />
        <Switch>
          <Route path="/job-list/:jobId" render={(routeProps) => (
            <div id="atttr">routeProps</div>
          )} />
          <Route path="/job-list" render={(routeProps) => (
            <JobList {...routeProps} store={this.store.getState().TodoReducer} handleJob={this.applyJob} />
          )} />
          <Route path="/job-list" render={(routeProps) => (
            <div>Good Morning</div>
          )} />
        </Switch>
        <Route path="/form" render={(routeProps) => (
          <Form {...routeProps} job={this.state.job} onsubmit={this.handleSubmit} />
        )} />
        <Route path="/applied-jobs" render={(routeProps) => (
          <AppliedJobs appliedList={} />
        )} />
      </div>
    );
  }
}

export default Homepage;
