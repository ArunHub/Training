import React from 'react';

class Shared extends React.Component {
    render(){
        return (
            <div>shared works</div>
        )
    }
}

export default Shared;