import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router} from 'react-router-dom';
import Homepage from './homepage';

class App extends Component {
 
  render() {
    return (
      <Router>
        <Homepage />
      </Router>
    );
  }
}

export default App;
