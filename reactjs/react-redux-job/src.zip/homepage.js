import React, { Component } from 'react';
import Header from "./header/header";
import { Route, Switch } from 'react-router-dom';
import JobList from './job-list/job-list';
import jobService from './service';
import Form from "./form/form";
import AppliedJobs from "./applied-jobs";

class Homepage extends Component {

  constructor(props) {
    super(props);
    this.state = {
      jobList: [],
      jobId: null,
      appliedList: [],
      job: null
    }
    this.applyJob = this.applyJob.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  joblist;

  componentDidMount() {
    jobService.getCMS().then((success) => {
      this.joblist = success.content;
      this.setState({
        jobList: success.content
      })
    },
      (error) => {
        console.log('errrow while receive response', error)
      });
  }

  applyJob(val) {
    if (val.positions === 0) return false;
    val.positions--;
    let newArr = jobService.calcPosition(this.joblist, val);
    this.setState({
      joblist: newArr,
      job: val
    })
  }

  handleSubmit(val) {
    this.setState(() => {
      this.state.appliedList.push(val)
    });
  }

  render() {
    return (
      <div className="App">
        <Header />
        <Route path="/" exact />
        <Switch>
          <Route path="/job-list/:jobId" render={(routeProps) => (
            <div id="atttr">routeProps</div>
          )} />
          <Route path="/job-list" render={(routeProps) => (
            <JobList {...routeProps} jobList={this.joblist} handleJob={this.applyJob} />
          )} />
          <Route path="/job-list" render={(routeProps) => (
            <div>Good Morning</div>
          )} />
        </Switch>
        <Route path="/form" render={(routeProps) => (
          <Form {...routeProps} job={this.state.job} onsubmit={this.handleSubmit} />
        )} />
        <Route path="/applied-jobs" render={(routeProps) => (
          <AppliedJobs appliedList={this.state.appliedList} />
        )} />
      </div>
    );
  }
}

export default Homepage;
