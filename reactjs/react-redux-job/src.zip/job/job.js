import React from 'react';
import { Link } from 'react-router-dom';

const Job = (props) => {
    let job = props.job;

    const applyJob = () => {
        props.handleJob(job);
    }

    return (
        <tr>
            <td>{job.id}</td>
            <td>{job.name}</td>
            <td>{job.positions}</td>
            <td><button onClick={applyJob}><Link to="/form">Apply</Link></button></td>
        </tr>
    )
}

export default Job;