import React, { Component } from 'react';

class BB extends Component {
    render() {
        return (
            <div>
            <footer>footer content</footer>
            </div>
        );
    }
}


export let vv = <div>machi</div>;
export default BB;