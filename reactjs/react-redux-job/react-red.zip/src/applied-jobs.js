import React from 'react';
import { connect } from 'react-redux'

const AppliedJobs = ({ list }) => {
    const appliedlist = list.map((t, i) => {
        return <div key={i}> {t.name} applied for : {t.jobname} </div>;
    });
    return (
        (appliedlist.length > 0) ?
            <div>{appliedlist}</div>
            : <div>No jobs applied</div>
    )
}

let mapStatetoProps = (state) => {
    return { list: state.TodoReducer.appliedJobs };
};

export default connect(mapStatetoProps, null)(AppliedJobs);