export let mummy = {
  first: 12,
  second: 0
};