import React from 'react';
import Job from '../job/job';
import { connect } from 'react-redux'

const JobList = ({list, handleJob}) => {
    let jobList;

    if (list.length>0) {
        jobList = list.map((t) =>
            <Job job={t} key={t.id} handleJob={handleJob}/>
        )
    }

    return (
        <table border="2" width="100%" align="center">
            <thead>
                <tr>
                    <th>id</th>
                    <th>job name</th>
                    <th>no of positions</th>
                    <th>action</th>
                </tr>
            </thead>
            <tbody align="center">
                {jobList}
            </tbody>
        </table>
    )
}

let mapStatetoProps= (state) => {
    return {list: state.TodoReducer.cms};
  };
  
  let mapDispatchtoProps= (dispatch) => {
    return {};
  };
  
export default connect(mapStatetoProps, mapDispatchtoProps)(JobList);
// export default JobList;