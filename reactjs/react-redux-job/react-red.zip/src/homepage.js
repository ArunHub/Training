import React, { Component } from 'react';
import Header from "./header/header";
import { Route, Switch, Link } from 'react-router-dom';
import JobList from './job-list/job-list';
// import jobService from './service';
import { withRouter } from 'react-router'
import Form from "./form/form";
import AppliedJobs from "./applied-jobs";
import { fetchCms, decrPos, applyJob } from './actions/actions';
import { connect } from 'react-redux'
import Saturday from './saturday'
import ModalSwitch from './router/modalexample';
import ReactChildren from './react-children-map/react-children';


class Homepage extends Component {
  store;

  constructor(props) {
    super(props);
    this.store = props.store;

    this.state = {
      job: null
    }
    this.applyJob = this.applyJob.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidMount() {
    const url = "./data/content.json"

    // jobService.getCMS(url).then((success) => {
    //   this.props.store.dispatch(loadCms(success.content));
    // },
    //   (error) => {
    //     console.log('errrow while receive response', error)
    //   });

    this.props.fetchData(url);
  }

  static getDerivedStateFromProps(props, state) {
    console.log('getderived',props, state)
    return true;
  }
  shouldComponentUpdate(nextProps, nextState){
    console.log('nextProps',nextProps);
    console.log('nextState',nextState);
    return true;
  }

  componentDidUpdate(prevProps, prevState, snapshot){
    console.log('prevProps',prevProps);
    console.log('prevState',prevState);
    console.log('snapshot',snapshot);
  }

  applyJob(val) {
    if (val.positions === 0) return false;
    this.store.dispatch(decrPos(val.id));
    this.setState({
      job: val
    })
  }

  handleSubmit(val) {
    this.store.dispatch(applyJob(val));
  }

  render() {
    return (
      <div className="App">
        <Link to="/parent-child">Friday bhai</Link>
        <Header />
        <Route path="/" exact />
        <Switch>
          <Route path="/job-list/:jobId" render={() => (
            <div id="atttr">routeProps</div>
          )} />
          <Route path="/job-list" render={(routeProps) => (
            <JobList {...routeProps} handleJob={this.applyJob} />
          )} />
          <Route path="/job-list" render={() => (
            <div>Good Morning</div>
          )} />
        </Switch>
        <Route path="/form" render={(routeProps) => (
          <Form {...routeProps} job={this.state.job} onsubmit={this.handleSubmit} />
        )} />
        <Route path="/applied-jobs" render={() => (
          <AppliedJobs />
        )} />
        <Route path="/parent-child" component={Saturday} />

        <Route path="/modal-switch" component={ModalSwitch} />

        <div className="reactchildren">
          <ReactChildren>
            <div>react child working using ReactChildren map</div>
            <div>just props.children.map wont work</div>
          </ReactChildren>
        </div>
      </div>
    );
  }
}

let mapStatetoProps= (state, ownProps) => {
  console.log('ownProps',ownProps)
  return {appliedJobs: state.TodoReducer.appliedJobs, jobitems: state.TodoReducer  };
};

let mapDispatchtoProps= (dispatch) => {
  return { fetchData: (url) => dispatch(fetchCms(url))}
};

export default withRouter(connect(mapStatetoProps, mapDispatchtoProps)(Homepage));
// export default Homepage;
