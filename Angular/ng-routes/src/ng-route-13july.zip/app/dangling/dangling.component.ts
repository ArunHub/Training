import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dangling',
  templateUrl: './dangling.component.html',
  styleUrls: ['./dangling.component.css']
})
export class DanglingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
