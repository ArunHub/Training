import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m1',
  templateUrl: './m1.component.html',
  styleUrls: ['./m1.component.scss']
})
export class M1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
