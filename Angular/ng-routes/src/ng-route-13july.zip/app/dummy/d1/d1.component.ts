import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-d1',
  templateUrl: './d1.component.html',
  styleUrls: ['./d1.component.scss']
})
export class D1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
