import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { D1Component } from './d1/d1.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [D1Component]
})
export class DummyModule { }
