import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apocalyse',
  templateUrl: './apocalyse.component.html',
  styleUrls: ['./apocalyse.component.css']
})
export class ApocalyseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
