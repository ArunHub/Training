import { Component } from '@angular/core';

@Component({
  template: `
    <p>Dashboard</p>
  `
})
export class AdminDashboardComponent { }